// Gujarati language adapter (stub)
const GL_ENDPOINT = process.env.GL_ENDPOINT || '';
const GL_API_KEY = process.env.GL_API_KEY || '';

exports.checkGujarati = async function(text) {
  // Stub: return empty issues; extend with real API call later.
  return { ok: true, issues: [] };
};
